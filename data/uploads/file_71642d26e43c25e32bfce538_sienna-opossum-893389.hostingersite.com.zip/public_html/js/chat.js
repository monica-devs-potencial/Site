/* chat.js – client-side logic for the instant messaging site */

(function () {
    'use strict';

    const messagesEl      = document.getElementById('messages');
    const chatForm        = document.getElementById('chat-form');
    const messageInput    = document.getElementById('message-input');
    const usersListEl     = document.getElementById('users-list');
    const emojiBtn        = document.getElementById('emoji-btn');
    const emojiPicker     = document.getElementById('emoji-picker');
    const emojiGrid       = document.getElementById('emoji-grid');
    const imageInput      = document.getElementById('image-input');
    const imagePreviewWrap = document.getElementById('image-preview-wrap');
    const imagePreview    = document.getElementById('image-preview');
    const imageRemoveBtn  = document.getElementById('image-remove');

    let lastMessageId   = 0;
    let pollTimer       = null;
    let consecutiveFail = 0;
    let statusBanner    = null;
    let isAdmin         = !!IS_ADMIN;

    // ── Emoji list ────────────────────────────────────────────────────────────
    const EMOJIS = [
        '😀','😁','😂','🤣','😃','😄','😅','😆','😉','😊',
        '😋','😎','😍','😘','🥰','😗','😙','😚','🙂','🤗',
        '🤩','🤔','🤨','😐','😑','😶','🙄','😏','😣','😥',
        '😮','🤐','😯','😪','😫','🥱','😴','😌','😛','😜',
        '😝','🤤','😒','😓','😔','😕','🙃','🤑','😲','☹️',
        '🙁','😖','😞','😟','😤','😢','😭','😦','😧','😨',
        '😩','🤯','😬','😰','😱','🥵','🥶','😳','🤪','😵',
        '😡','😠','🤬','😷','🤒','🤕','🤢','🤮','🤧','🥴',
        '😇','🥳','🥸','🤠','🤡','🤥','🤫','🤭','🧐','🤓',
        '👋','🤚','🖐️','✋','🖖','👌','🤌','🤏','✌️','🤞',
        '🤟','🤘','🤙','👈','👉','👆','👇','👍','👎','✊',
        '👊','🤛','🤜','👏','🙌','🤲','🤝','🙏','❤️','🧡',
        '💛','💚','💙','💜','🖤','🤍','🤎','💔','💯','🔥',
        '⭐','✨','🎉','🎊','🎈','🎁','🎀','🎂','🍕','🍔',
    ];

    // Build emoji grid
    EMOJIS.forEach(function (em) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'emoji-item';
        btn.textContent = em;
        btn.setAttribute('aria-label', em);
        btn.addEventListener('click', function () {
            const start = messageInput.selectionStart;
            const end   = messageInput.selectionEnd;
            const val   = messageInput.value;
        // em.length gives UTF-16 code units — correct for selectionStart/selectionEnd.
        // Multi-code-unit emoji (e.g. 👋 = 2 units) are handled properly by this.
            messageInput.value = val.slice(0, start) + em + val.slice(end);
            messageInput.selectionStart = messageInput.selectionEnd = start + em.length;
            messageInput.focus();
        });
        emojiGrid.appendChild(btn);
    });

    // Toggle emoji picker
    emojiBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        emojiPicker.hidden = !emojiPicker.hidden;
    });

    // Close picker when clicking or touching outside (iOS Safari doesn't fire
    // 'click' on non-interactive elements, so we need 'touchstart' too)
    function closePickerOnOutside(e) {
        if (!emojiPicker.hidden && !emojiPicker.contains(e.target) && !emojiBtn.contains(e.target)) {
            emojiPicker.hidden = true;
        }
    }
    document.addEventListener('click',      closePickerOnOutside);
    document.addEventListener('touchstart', closePickerOnOutside, { passive: true });

    // ── Image attach ──────────────────────────────────────────────────────────
    imageInput.addEventListener('change', function () {
        const file = imageInput.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = function (ev) {
            imagePreview.src = ev.target.result;
            imagePreviewWrap.hidden = false;
        };
        reader.readAsDataURL(file);
    });

    imageRemoveBtn.addEventListener('click', function () {
        imageInput.value = '';
        imagePreview.src = '';
        imagePreviewWrap.hidden = true;
    });

    // ── Helpers ───────────────────────────────────────────────────────────────

    function escapeHtml(text) {
        const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
        return text.replace(/[&<>"']/g, m => map[m]);
    }

    function scrollToBottom(force) {
        if (force || (messagesEl.scrollHeight - messagesEl.scrollTop - messagesEl.clientHeight < 60)) {
            messagesEl.scrollTop = messagesEl.scrollHeight;
        }
    }

    function showStatus(msg) {
        if (!statusBanner) {
            statusBanner = document.createElement('div');
            statusBanner.className = 'status-banner';
            document.getElementById('chat-panel').prepend(statusBanner);
        }
        statusBanner.textContent = msg;
        statusBanner.style.display = 'block';
    }

    function hideStatus() {
        if (statusBanner) statusBanner.style.display = 'none';
        consecutiveFail = 0;
    }

    // ── Avatar helpers ────────────────────────────────────────────────────────

    function getAvatarColor(username) {
        let hash = 0;
        for (let i = 0; i < username.length; i++) {
            hash = (username.charCodeAt(i) + ((hash << 5) - hash)) | 0;
        }
        const hue = Math.abs(hash) % 360;
        return 'hsl(' + hue + ',60%,42%)';
    }

    // ── Render a single message bubble ────────────────────────────────────────

    function renderMessage(msg) {
        const isOwn   = msg.username === CURRENT_USER;
        const deleted = !!msg.deleted_at;

        const div = document.createElement('div');
        div.className = 'message ' + (isOwn ? 'own' : 'other') + (deleted ? ' deleted' : '');
        div.dataset.id = msg.id;

        const initial      = escapeHtml(msg.username.charAt(0).toUpperCase());
        const avatarColor  = getAvatarColor(msg.username);

        // Delete button (admin only, inside the timestamp span)
        const deleteBtn = (isAdmin && !deleted)
            ? '<button class="btn-delete-msg" data-id="' + escapeHtml(String(msg.id)) + '" title="Apagar mensagem">🗑️</button>'
            : '';

        // Timestamp rendered INSIDE the bubble (WhatsApp style)
        const timeHtml = '<span class="bubble-time">' + escapeHtml(msg.created_at) + deleteBtn + '</span>';

        let bodyHtml = '';

        if (deleted) {
            bodyHtml = '<div class="message-bubble deleted-bubble">🗑️ Mensagem apagada' + timeHtml + '</div>';
        } else {
            let contentHtml = '';
            if (msg.content) {
                contentHtml = '<div class="message-bubble">' + escapeHtml(msg.content) + timeHtml + '</div>';
            }
            let imageHtml = '';
            if (msg.image_path) {
                const src = escapeHtml('data/uploads/' + msg.image_path);
                imageHtml = '<div class="message-bubble message-image-bubble">' +
                    '<img src="' + src + '" class="chat-image" alt="imagem" loading="lazy">' +
                    timeHtml +
                    '</div>';
            }
            bodyHtml = imageHtml + contentHtml;
        }

        // Sender name shown above the bubble for other users only
        const senderHtml = isOwn
            ? ''
            : '<div class="message-sender" style="color:' + avatarColor + '">' + escapeHtml(msg.username) + '</div>';

        // Avatar shown on the left for other users only
        const avatarHtml = isOwn
            ? ''
            : '<span class="msg-avatar" style="background:' + avatarColor + '" aria-hidden="true">' + initial + '</span>';

        div.innerHTML =
            '<div class="message-inner">' +
                avatarHtml +
                '<div class="message-content">' +
                    senderHtml +
                    bodyHtml +
                '</div>' +
            '</div>';

        return div;
    }

    // ── Mark a rendered message element as deleted ────────────────────────────

    function markDeletedInDOM(msgDiv) {
        msgDiv.classList.add('deleted');
        msgDiv.querySelector('.btn-delete-msg')?.remove();
        msgDiv.querySelectorAll('.message-bubble, .message-image-bubble').forEach(b => b.remove());
        const msgContent = msgDiv.querySelector('.message-content') || msgDiv;
        const deletedBubble = document.createElement('div');
        deletedBubble.className = 'message-bubble deleted-bubble';
        deletedBubble.textContent = '🗑️ Mensagem apagada';
        msgContent.appendChild(deletedBubble);
    }

    // ── Admin delete ──────────────────────────────────────────────────────────

    messagesEl.addEventListener('click', function (e) {
        const btn = e.target.closest('.btn-delete-msg');
        if (!btn) return;

        const id = btn.dataset.id;
        if (!id) return;

        if (!confirm('Apagar esta mensagem?')) return;

        const body = new FormData();
        body.append('id', id);

        fetch('api/delete.php', {
            method: 'POST',
            body: body,
            credentials: 'same-origin'
        })
            .then(r => r.json())
            .then(data => {
                if (data.ok) {
                    // Mark the bubble as deleted locally without waiting for next poll
                    const msgDiv = messagesEl.querySelector('.message[data-id="' + id + '"]');
                    if (msgDiv) {
                        markDeletedInDOM(msgDiv);
                    }
                } else {
                    showStatus('❌ ' + (data.error || 'Não foi possível apagar a mensagem'));
                }
            })
            .catch(function () {
                showStatus('❌ Erro ao apagar mensagem.');
            });
    });

    // ── Load messages ─────────────────────────────────────────────────────────

    function loadMessages(initial) {
        const url = 'api/messages.php' + (lastMessageId > 0 ? '?since=' + lastMessageId : '');

        return fetch(url, { credentials: 'same-origin' })
            .then(r => r.json())
            .then(data => {
                // Update admin status from server (in case session changed)
                if (typeof data.is_admin !== 'undefined') {
                    isAdmin = !!data.is_admin;
                }

                const msgs = data.messages || [];
                if (msgs.length === 0) return;

                const atBottom =
                    messagesEl.scrollHeight - messagesEl.scrollTop - messagesEl.clientHeight < 60;

                const fragment = document.createDocumentFragment();
                msgs.forEach(msg => {
                    lastMessageId = Math.max(lastMessageId, parseInt(msg.id, 10));

                    // If message already rendered, update deleted state
                    const existing = messagesEl.querySelector('.message[data-id="' + msg.id + '"]');
                    if (existing) {
                        if (msg.deleted_at && !existing.classList.contains('deleted')) {
                            markDeletedInDOM(existing);
                        }
                        return;
                    }

                    fragment.appendChild(renderMessage(msg));
                });
                messagesEl.appendChild(fragment);

                if (initial || atBottom) {
                    scrollToBottom(true);
                }

                hideStatus();
            })
            .catch(() => {
                consecutiveFail++;
                if (consecutiveFail >= 3) {
                    showStatus('⚠️ Sem conexão – tentando reconectar…');
                }
            });
    }

    // ── Load online users ─────────────────────────────────────────────────────

    function loadUsers() {
        fetch('api/users.php', { credentials: 'same-origin' })
            .then(r => r.json())
            .then(data => {
                const users = data.users || [];
                usersListEl.innerHTML = '';
                users.forEach(function (username) {
                    const li = document.createElement('li');
                    li.className = 'wa-user-item' + (username === CURRENT_USER ? ' is-me' : '');

                    const color   = getAvatarColor(username);
                    const initial = escapeHtml(username.charAt(0).toUpperCase());
                    const label   = username === CURRENT_USER
                        ? escapeHtml(username) + ' <em style="font-weight:400;color:var(--wa-muted)">(você)</em>'
                        : escapeHtml(username);

                    li.innerHTML =
                        '<span class="wa-user-avatar" style="background:' + color + '">' + initial + '</span>' +
                        '<span class="wa-user-name">' + label + '</span>' +
                        '<span class="wa-user-dot"></span>';

                    usersListEl.appendChild(li);
                });

                // Update chat header status line
                const panelStatus = document.getElementById('panel-status');
                if (panelStatus) {
                    panelStatus.textContent = users.length === 0
                        ? 'nenhum online'
                        : users.length === 1 ? '1 pessoa online' : users.length + ' pessoas online';
                }
            })
            .catch(function () { /* user list failure is non-critical; silently skip */ });
    }

    // ── Send a message ────────────────────────────────────────────────────────

    chatForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const content = messageInput.value.trim();
        const hasImage = imageInput.files && imageInput.files.length > 0;

        if (!content && !hasImage) return;

        // Close emoji picker if open
        emojiPicker.hidden = true;

        const btn = chatForm.querySelector('button[type="submit"]');
        btn.disabled = true;
        messageInput.disabled = true;

        const body = new FormData();
        body.append('content', content);
        if (hasImage) {
            body.append('image', imageInput.files[0]);
        }

        fetch('api/send.php', {
            method: 'POST',
            body: body,
            credentials: 'same-origin'
        })
            .then(r => r.json())
            .then(data => {
                if (data.ok) {
                    messageInput.value = '';
                    // Clear image
                    imageInput.value = '';
                    imagePreview.src = '';
                    imagePreviewWrap.hidden = true;
                    // Immediately poll so sender sees their own message
                    clearTimeout(pollTimer);
                    poll();
                } else {
                    showStatus('❌ Falha ao enviar: ' + (data.error || 'erro desconhecido'));
                }
            })
            .catch(() => {
                showStatus('❌ Mensagem não enviada. Verifique sua conexão.');
            })
            .finally(() => {
                btn.disabled = false;
                messageInput.disabled = false;
                messageInput.focus();
            });
    });

    // ── Allow Enter to submit ─────────────────────────────────────────────────
    messageInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            chatForm.dispatchEvent(new Event('submit'));
        }
    });

    // ── Polling loop ──────────────────────────────────────────────────────────

    function poll() {
        loadMessages(false).finally(() => {
            loadUsers();
            pollTimer = setTimeout(poll, 2000);
        });
    }

    // ── Initialise ────────────────────────────────────────────────────────────

    loadMessages(true).finally(() => {
        loadUsers();
        pollTimer = setTimeout(poll, 2000);
    });
    messageInput.focus();

})();

