<?php
require_once __DIR__ . '/config.php';
requireLogin();
$selfInitial = htmlspecialchars(mb_strtoupper(mb_substr($_SESSION['username'], 0, 1)));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap">
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="auth-page">
       <div class="auth-container">
        <div class="auth-box">
           <div class="wa-app">

       <!-- ── LEFT SIDEBAR ─────────────────────────────────────────────────── -->
    <aside class="wa-sidebar">

        <header class="wa-sidebar-header">
            <span class="wa-self-avatar" title="<?= htmlspecialchars($_SESSION['username']) ?>"><?= $selfInitial ?></span>
            <span class="wa-sidebar-title">💬 Chat</span>
            <a href="logout.php" class="wa-hdr-btn" title="Sair">
                <!-- door / logout icon -->
                <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true">
                    <path d="M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5-5-5zm-14 5V5h8V3H3a2 2 0 00-2 2v14a2 2 0 002 2h8v-2H3v-7z"/>
                </svg>
            </a>
        </header>

        <div class="wa-online-label">🟢 Online agora</div>

        <ul id="users-list" class="wa-users-list"></ul>

    </aside>

    <!-- ── RIGHT CHAT PANEL ─────────────────────────────────────────────── -->
    <section class="wa-panel" id="chat-panel">

        <!-- Chat header -->
        <header class="wa-panel-header">
            <div class="wa-panel-avatar">G</div>
            <div class="wa-panel-info">
                <div class="wa-panel-name">Chat Geral</div>
                <div class="wa-panel-status" id="panel-status">carregando…</div>
            </div>
            <div class="wa-panel-right">
                <span class="wa-self-name">👤 <?= htmlspecialchars($_SESSION['username']) ?></span>
            </div>
        </header>

        <!-- Messages -->
        <div id="messages" class="wa-messages"></div>

        <!-- Emoji picker (absolutely positioned above compose bar) -->
        <div id="emoji-picker" class="wa-emoji-picker" hidden>
            <div class="emoji-grid" id="emoji-grid"></div>
        </div>

        <!-- Image preview bar (shown when a file is selected) -->
        <div id="image-preview-wrap" hidden>
            <img id="image-preview" src="" alt="preview">
            <span style="flex:1;font-size:.82rem;color:var(--wa-muted)">Imagem selecionada</span>
            <button type="button" id="image-remove" title="Remover imagem">✕</button>
        </div>

        <!-- Compose bar -->
        <form id="chat-form" class="wa-compose" enctype="multipart/form-data">

            <!-- Emoji toggle -->
            <button type="button" id="emoji-btn" class="wa-compose-btn" title="Emojis">
                <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor" aria-hidden="true">
                    <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z"/>
                </svg>
            </button>

            <!-- Attach image -->
            <label class="wa-compose-btn" title="Enviar imagem" style="cursor:pointer">
                <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor" aria-hidden="true">
                    <path d="M16.5 6v11.5c0 2.21-1.79 4-4 4s-4-1.79-4-4V5a2.5 2.5 0 015 0v10.5c0 .83-.67 1.5-1.5 1.5s-1.5-.67-1.5-1.5V6H9v9.5a3.5 3.5 0 007 0V5c0-2.76-2.24-5-5-5S6 2.24 6 5v12.5c0 3.31 2.69 6 6 6s6-2.69 6-6V6h-1.5z"/>
                </svg>
                <input type="file" id="image-input" name="image" accept="image/*"
                       class="visually-hidden-input">
            </label>

            <!-- Text input -->
            <input
                type="text"
                id="message-input"
                class="wa-compose-input"
                placeholder="Digite uma mensagem"
                maxlength="500"
                autocomplete="off"
            >

            <!-- Send button -->
            <button type="submit" class="wa-send-btn" title="Enviar">
                <svg viewBox="0 0 24 24" width="20" height="20" fill="#fff" aria-hidden="true">
                    <path d="M2 21l21-9L2 3v7l15 2-15 2z"/>
                </svg>
            </button>

        </form>

    </section>
</div>
</div>
<script>
    const CURRENT_USER = <?= json_encode($_SESSION['username']) ?>;
    const IS_ADMIN     = <?= json_encode(isAdmin()) ?>;
</script>
<script src="js/chat.js"></script>
</body>
</html>
