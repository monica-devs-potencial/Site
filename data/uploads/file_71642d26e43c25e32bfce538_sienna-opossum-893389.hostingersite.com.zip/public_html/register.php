<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

if (isLoggedIn()) {
    redirect('index.php');
}

$error   = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';

    if ($username === '' || $password === '' || $confirm === '') {
        $error = 'Por favor, preencha todos os campos.';
    } elseif (strlen($username) < 3 || strlen($username) > 20) {
        $error = 'O nome de usuário deve ter entre 3 e 20 caracteres.';
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $error = 'O nome de usuário só pode conter letras, números e _.';
    } elseif (strlen($password) < 6) {
        $error = 'A senha deve ter pelo menos 6 caracteres.';
    } elseif ($password !== $confirm) {
        $error = 'As senhas não coincidem.';
    } else {
        $db = getDB();
        $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);

        if ($stmt->fetch()) {
            $error = 'Este nome de usuário já está em uso.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $db->prepare("INSERT INTO users (username, password) VALUES (?, ?)")
               ->execute([$username, $hash]);

            $success = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro – Chat</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap">
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="auth-box">
            <h1 class="auth-title">💬 Chat</h1>
            <h2 class="auth-subtitle">Cadastro</h2>
            <?php if ($error): ?>
                <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert-success">
                    Conta criada com sucesso! Você já pode <a href="login.php">entrar</a>.
                </div>
            <?php endif; ?>
            <form method="post" action="register.php" class="auth-form">
                <div class="form-group">
                    <label for="username">Usuário</label>
                    <input type="text" id="username" name="username" required
                           value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                           placeholder="3–20 caracteres, letras/números/_">
                </div>
                <div class="form-group">
                    <label for="password">Senha</label>
                    <input type="password" id="password" name="password" required
                           placeholder="Mínimo 6 caracteres">
                </div>
                <div class="form-group">
                    <label for="confirm">Confirmar senha</label>
                    <input type="password" id="confirm" name="confirm" required
                           placeholder="Repita a senha">
                </div>
                <button type="submit" class="btn btn-primary btn-full">Cadastrar</button>
            </form>
            <p class="auth-footer">Já tem conta? <a href="login.php">Entrar</a></p>
        </div>
    </div>
</body>
</html>
