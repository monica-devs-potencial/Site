<?php
require_once __DIR__ . '/config.php';

function getDB(): PDO {
    if (!is_dir(UPLOADS_DIR)) {
        mkdir(UPLOADS_DIR, 0755, true);
    }

    $dsn = sprintf(
        'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
        MYSQL_HOST,
        MYSQL_PORT,
        MYSQL_DATABASE
    );

    try {
        $pdo = new PDO($dsn, MYSQL_USER, MYSQL_PASSWORD, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
        ]);
    } catch (\PDOException $e) {
        // Determina se é uma chamada de API (espera JSON) ou página web
        $isApi = str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/api/');
        if ($isApi) {
            http_response_code(503);
            header('Content-Type: application/json; charset=utf-8');
            exit(json_encode(['error' => 'Banco de dados indisponível'], JSON_UNESCAPED_UNICODE));
        }
        http_response_code(503);
        exit(
            '<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">' .
            '<title>Erro de conexão</title>' .
            '<style>body{font-family:system-ui,sans-serif;max-width:600px;margin:4rem auto;padding:1rem;color:#1e293b}' .
            'h1{color:#ef4444}pre{background:#fee2e2;padding:1rem;border-radius:8px;white-space:pre-wrap;font-size:.85rem}' .
            '.btn{display:inline-block;margin-top:1rem;padding:.6rem 1.4rem;background:#4f46e5;color:#fff;border-radius:8px;text-decoration:none}</style>' .
            '</head><body>' .
            '<h1>&#x274C; Falha ao conectar ao banco de dados</h1>' .
            '<p>Verifique as credenciais em <code>config.local.php</code> ou <code>.env</code>.</p>' .
            '<pre>' . htmlspecialchars($e->getMessage()) . '</pre>' .
            '<a href="setup.php" class="btn">&#x2699;&#xFE0F; Abrir assistente de configuração</a>' .
            '</body></html>'
        );
    }

    // Create tables if they do not exist yet (utf8mb4 for full emoji support)
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        username   VARCHAR(20) NOT NULL,
        password   VARCHAR(255) NOT NULL,
        is_admin   TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_seen  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_username (username)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS messages (
        id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id    INT UNSIGNED NOT NULL,
        username   VARCHAR(20) NOT NULL,
        content    TEXT NOT NULL DEFAULT '',
        image_path VARCHAR(255),
        deleted_at DATETIME,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY idx_messages_id (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    return $pdo;
}
