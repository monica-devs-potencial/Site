<?php
mb_internal_encoding('UTF-8');
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';

header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Não autenticado'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método não permitido'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$content   = trim($_POST['content'] ?? '');
$imagePath = null;

// ── Handle optional image upload ─────────────────────────────────────────────
if (!empty($_FILES['image']['tmp_name'])) {
    $file = $_FILES['image'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        http_response_code(400);
        echo json_encode(['error' => 'Erro no upload da imagem'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    if ($file['size'] > MAX_IMG_SIZE) {
        http_response_code(400);
        echo json_encode(['error' => 'Imagem muito grande (máx. 5 MB)'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    // Validate by inspecting actual file contents, not the client-supplied MIME type
    $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $finfo   = new finfo(FILEINFO_MIME_TYPE);
    $mime    = $finfo->file($file['tmp_name']);

    if (!in_array($mime, $allowed, true)) {
        http_response_code(400);
        echo json_encode(['error' => 'Tipo de arquivo não permitido (use JPEG, PNG, GIF ou WebP)'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $ext      = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp'][$mime];
    $filename = bin2hex(random_bytes(16)) . '.' . $ext;

    if (!is_dir(UPLOADS_DIR)) {
        mkdir(UPLOADS_DIR, 0755, true);
    }

    $dest = UPLOADS_DIR . '/' . $filename;
    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        http_response_code(500);
        echo json_encode(['error' => 'Não foi possível salvar a imagem'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $imagePath = $filename;
}

// ── Validate text content ─────────────────────────────────────────────────────
// A message must have text or an image
if ($content === '' && $imagePath === null) {
    http_response_code(400);
    echo json_encode(['error' => 'Mensagem vazia'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (mb_strlen($content, 'UTF-8') > 500) {
    http_response_code(400);
    echo json_encode(['error' => 'Mensagem muito longa (máx. 500 caracteres)'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$db = getDB();

$db->prepare("UPDATE users SET last_seen = CURRENT_TIMESTAMP WHERE id = ?")
   ->execute([$_SESSION['user_id']]);

$stmt = $db->prepare("INSERT INTO messages (user_id, username, content, image_path) VALUES (?, ?, ?, ?)");
$stmt->execute([$_SESSION['user_id'], $_SESSION['username'], $content, $imagePath]);

$id = $db->lastInsertId();

echo json_encode(['ok' => true, 'id' => (int)$id], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

