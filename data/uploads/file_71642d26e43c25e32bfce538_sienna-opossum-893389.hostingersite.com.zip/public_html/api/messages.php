<?php
mb_internal_encoding('UTF-8');
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';

header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Não autenticado'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$db = getDB();

$db->prepare("UPDATE users SET last_seen = CURRENT_TIMESTAMP WHERE id = ?")
   ->execute([$_SESSION['user_id']]);

$since = isset($_GET['since']) ? (int)$_GET['since'] : 0;

if ($since > 0) {
    $stmt = $db->prepare(
        "SELECT id, username, content, image_path, deleted_at,
                DATE_FORMAT(created_at, '%d/%m/%Y %H:%i') AS created_at
         FROM messages WHERE id > ? ORDER BY id ASC LIMIT 100"
    );
    $stmt->execute([$since]);
} else {
    $stmt = $db->prepare(
        "SELECT id, username, content, image_path, deleted_at,
                DATE_FORMAT(created_at, '%d/%m/%Y %H:%i') AS created_at
         FROM messages ORDER BY id DESC LIMIT 50"
    );
    $stmt->execute();
}

$messages = $stmt->fetchAll();

if ($since === 0) {
    $messages = array_reverse($messages);
}

echo json_encode(['messages' => $messages, 'is_admin' => isAdmin() ? 1 : 0], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

