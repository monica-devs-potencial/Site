<?php
mb_internal_encoding('UTF-8');
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';

header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Não autenticado'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$db = getDB();

// Users are considered "online" if last_seen within the last 2 minutes
$stmt = $db->query(
    "SELECT username FROM users
     WHERE last_seen >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)
     ORDER BY username ASC"
);

$users = $stmt->fetchAll(PDO::FETCH_COLUMN);

echo json_encode(['users' => $users], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
