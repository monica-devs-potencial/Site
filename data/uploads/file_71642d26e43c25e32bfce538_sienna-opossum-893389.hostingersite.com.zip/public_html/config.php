<?php
// ─────────────────────────────────────────────────────────────────────────────
//  Carregamento de credenciais — ordem de prioridade:
//    1. config.local.php  (criado pelo setup.php ou manualmente)
//    2. .env              (variáveis no formato CHAVE=valor)
//    3. Variáveis de ambiente do servidor (Docker / cPanel)
//    4. Valores padrão — se ainda vazios, redireciona para setup.php
// ─────────────────────────────────────────────────────────────────────────────

// 1. config.local.php
$_localCfg = __DIR__ . '/config.local.php';
if (is_file($_localCfg)) {
    require $_localCfg;
}
unset($_localCfg);

// 2. .env
$_envFile = __DIR__ . '/.env';
if (is_file($_envFile)) {
    foreach (file($_envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $_line) {
        $_line = trim($_line);
        if ($_line === '' || $_line[0] === '#' || !str_contains($_line, '=')) {
            continue;
        }
        [$_k, $_v] = explode('=', $_line, 2);
        $_k = trim($_k);
        $_v = trim($_v);
        if ($_k !== '' && getenv($_k) === false) {
            putenv("$_k=$_v");
            $_ENV[$_k] = $_v;
        }
    }
    unset($_line, $_k, $_v);
}
unset($_envFile);

// 3 & 4. Define constants (if not already defined by config.local.php)
if (!defined('MYSQL_HOST'))     define('MYSQL_HOST',     getenv('MYSQL_HOST')     ?: 'localhost');
if (!defined('MYSQL_PORT'))     define('MYSQL_PORT',     getenv('MYSQL_PORT')     ?: '3306');
if (!defined('MYSQL_DATABASE')) define('MYSQL_DATABASE', getenv('MYSQL_DATABASE') ?: 'u971648951_db_chat');
if (!defined('MYSQL_USER'))     define('MYSQL_USER',     getenv('MYSQL_USER')     ?: 'u971648951_user_chat');
if (!defined('MYSQL_PASSWORD')) define('MYSQL_PASSWORD', getenv('MYSQL_PASSWORD') ?: '170575@As');

// Se as credenciais não foram configuradas, redireciona para o assistente de instalação
if ((MYSQL_DATABASE === '' || MYSQL_USER === '') && PHP_SAPI !== 'cli') {
    $__script = basename($_SERVER['SCRIPT_FILENAME'] ?? '');
    if ($__script !== 'setup.php') {
        header('Location: setup.php');
        exit;
    }
    unset($__script);
}

// ── File / upload settings ───────────────────────────────────────────────────
define('DATA_DIR',    __DIR__ . '/data');
define('UPLOADS_DIR', __DIR__ . '/data/uploads');
define('UPLOADS_URL', 'data/uploads/');
define('MAX_IMG_SIZE', 5 * 1024 * 1024); // 5 MB

session_start();

function isLoggedIn(): bool {
    return isset($_SESSION['user_id']) && isset($_SESSION['username']);
}

function isAdmin(): bool {
    return !empty($_SESSION['is_admin']);
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

function redirect(string $url): void {
    header('Location: ' . $url);
    exit;
}
